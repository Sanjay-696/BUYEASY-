package com.project.ecommerce.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.project.ecommerce.dao.CustomerRepository;
import com.project.ecommerce.dto.CustomerDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.entity.CustomerEntity;
import com.project.ecommerce.service.CustomerService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

	private final CustomerRepository customerRepository;

	@Override
	public CustomerDto getCustomerDetailsById(String customerId) {
		CustomerDto dto = new CustomerDto();
		Optional<CustomerEntity> customerOpt = customerRepository.findById(customerId);

		if (customerOpt.isPresent()) {
			CustomerEntity customer = customerOpt.get();
			dto.setCustomerId(customer.getCustomerId());
			dto.setCustomerName(customer.getCustomerName());
			dto.setMobileNumber(customer.getMobileNumber());
			dto.setEmail(customer.getEmail());
			dto.setAddress(customer.getAddress());
			dto.setCreatedAt(customer.getCreatedAt());
		}
		return dto;
	}

	@Override
	public ResponseDto saveCustomerDetails(CustomerDto dto) {
		ResponseDto response = new ResponseDto();

		try {
			CustomerEntity customer = new CustomerEntity();

			if (dto.getCustomerId() != null) {
				Optional<CustomerEntity> customerOpt = customerRepository.findById(dto.getCustomerId());
				if (customerOpt.isPresent()) {
					customer = customerOpt.get();
					customer.setCustomerName(dto.getCustomerName());
					customer.setMobileNumber(dto.getMobileNumber());
					customer.setEmail(dto.getEmail());
					customer.setAddress(dto.getAddress());
					customer.setCreatedAt(dto.getCreatedAt());
				}
			} else {
				customer.setCustomerName(dto.getCustomerName());
				customer.setMobileNumber(dto.getMobileNumber());
				customer.setEmail(dto.getEmail());
				customer.setAddress(dto.getAddress());
				customer.setCreatedAt(dto.getCreatedAt());
			}

			customerRepository.save(customer);
			response.setMessage("SUCCESS");
			response.setStatusCode("200");
		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}

		return response;
	}

	@Override
	public List<CustomerDto> getAllCustomerDetails() {
		try {
			List<CustomerEntity> customerList = customerRepository.findAll();
			List<CustomerDto> dtoList = new ArrayList<>();

			customerList.forEach(entity -> {
				CustomerDto dto = new CustomerDto();
				dto.setCustomerId(entity.getCustomerId());
				dto.setCustomerName(entity.getCustomerName());
				
				dto.setEmail(entity.getEmail());
				dto.setMobileNumber(entity.getMobileNumber());
				
				dtoList.add(dto);
			});

			return dtoList;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public ResponseDto deleteCustomerById(String customerId) {
		ResponseDto response = new ResponseDto();

		try {
			if (customerRepository.existsById(customerId)) {
				customerRepository.deleteById(customerId);
				response.setMessage("DELETE SUCCESSFULLY");
				response.setStatusCode("200");
			} else {
				response.setMessage("CUSTOMER ID NOT FOUND");
			}
		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}

		return response;
	}


}
