package com.project.ecommerce.service;

import java.util.List;

import com.project.ecommerce.dto.ProductDto;
import com.project.ecommerce.dto.ResponseDto;

public interface ProductService {

	

	ResponseDto saveProductDetails(ProductDto dto);

	List<ProductDto> getAllProductDetails();

	ResponseDto deleteProductById(String productId);

	ProductDto getProductByName(String productName);

	
	
	
	
	

}
