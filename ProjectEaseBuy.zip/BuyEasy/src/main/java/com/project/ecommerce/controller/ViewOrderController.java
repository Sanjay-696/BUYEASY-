package com.project.ecommerce.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.ecommerce.dto.OrderResponseDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.dto.ViewOrderDto;
import com.project.ecommerce.service.ViewOrderService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("api")
@RequiredArgsConstructor
public class ViewOrderController {

    private final ViewOrderService viewOrderService;

    @GetMapping("/vieworder/{orderId}")
    public ResponseEntity<List<ViewOrderDto>> getItemsByOrderId(@PathVariable String orderId) {
        return ResponseEntity.ok(viewOrderService.getItemsByOrderId(orderId));
    }

    
    @GetMapping("/viewcustomer/{customerId}")
    public ResponseEntity<OrderResponseDto> getOrderDetailsByCustomerId(@PathVariable String customerId) {
        return ResponseEntity.ok(viewOrderService.getOrderDetailsByCustomerId(customerId));
    }

    @GetMapping("/vieworderitems")
    public ResponseEntity<List<ViewOrderDto>> getAllItems() {
        return ResponseEntity.ok(viewOrderService.getAllItems());
    }

   
    @DeleteMapping("/deletevieworder/{orderId}")
    public ResponseEntity<ResponseDto> deleteItemsByOrderId(@PathVariable String orderId) {
        return ResponseEntity.ok(viewOrderService.deleteItemsByOrderId(orderId));
    }
}
