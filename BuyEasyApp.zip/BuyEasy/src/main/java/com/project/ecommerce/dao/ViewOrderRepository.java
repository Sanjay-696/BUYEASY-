package com.project.ecommerce.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.ecommerce.entity.ViewOrderEntity;

public interface ViewOrderRepository extends JpaRepository<ViewOrderEntity, String> {

    List<ViewOrderEntity> findByOrderOrderId(String orderId);

    List<ViewOrderEntity> findByCustomerCustomerId(String customerId);

    void deleteByOrderOrderId(String orderId);
}
