package com.project.ecommerce.dto;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ViewOrderDto {

	private String itemId;
	
	private String orderId;
	
	private String customerId;
	
	private String productId;
	
	private String productName;
	
	private int quantity;
	
	private int mrp;
	
	private int price;
	
	private int tax;
	
	private int totalAmount;
	
	
}
