package com.project.ecommerce.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.project.ecommerce.dao.ProductRepository;
import com.project.ecommerce.dto.ProductDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.entity.ProductEntity;
import com.project.ecommerce.service.ProductService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService{

	private final ProductRepository productRepository;
	@Override
	public ProductDto getProductDetailsById(String productId) {
		ProductDto dto=new ProductDto();
		Optional<ProductEntity> productOpt = productRepository.findById(productId);

		if (productOpt.isPresent()) {
			ProductEntity product= productOpt.get();
			dto.setProductName(product.getProductName());
			dto.setMrp(product.getMrp());
			dto.setPrice(product.getPrice());
			dto.setTax(product.getTax());
			dto.setCreatedAt(product.getCreatedAt());			
		}
		return dto;
	}

	@Override
	public ResponseDto saveProductDetails(ProductDto dto) {
		ResponseDto response = new ResponseDto();

		try {
			ProductEntity product = new ProductEntity();

			if (dto.getProductId() != null) {
				Optional<ProductEntity> productOpt = productRepository.findById(dto.getProductId());
				if (productOpt.isPresent()) {
					product = productOpt.get();
					product.setProductName(dto.getProductName());
					product.setMrp(dto.getMrp());
					product.setPrice(dto.getPrice());
					product.setTax(dto.getTax());
					product.setCreatedAt(dto.getCreatedAt());
					
				}
			} else {
				product.setProductName(dto.getProductName());
				product.setMrp(dto.getMrp());
				product.setPrice(dto.getPrice());
				product.setTax(dto.getTax());
				product.setCreatedAt(dto.getCreatedAt());
			}

			productRepository.save(product);
			response.setMessage("SUCCESS");
			response.setStatusCode("200");
		} catch (Exception e) {
			response.setMessage("FAILURE");
			throw e;
		}

		return response;
	}

	@Override
	public List<ProductDto> getAllProductDetails() {
		ResponseDto response= new ResponseDto();
		try {
			List<ProductEntity> productList = productRepository.findAll();
			List<ProductDto> dtoList = new ArrayList<>();

			productList.forEach(entity -> {
				ProductDto dto = new ProductDto();
				dto.setProductId(entity.getProductId());
				dto.setProductName(entity.getProductName());
				dto.setMrp(entity.getMrp());
				dto.setPrice(entity.getPrice());
				dto.setTax(entity.getTax());
				dto.setCreatedAt(entity.getCreatedAt());
				dtoList.add(dto);
			});
			response.setMessage("These are the Products");
			return dtoList;
			
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public ResponseDto deleteProductById(String productId) {
		ResponseDto response = new ResponseDto();

		try {
			if (productRepository.existsById(productId)) {
				productRepository.deleteById(productId);
				response.setMessage("DELETE SUCCESSFULLY");
				response.setStatusCode("200");
			} else {
				response.setMessage("CUSTOMER ID NOT FOUND");
			}
		} catch (Exception e) {
			response.setMessage("FAILED");
			throw e;
		}

		return response;
	}

}
