package com.project.ecommerce.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ecommerce.dto.CustomerDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.service.CustomerService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("api")
@RequiredArgsConstructor
public class CustomerController {

	private final CustomerService customerService; 

	@GetMapping("/customer/{customerId}")
	public ResponseEntity<CustomerDto> getCustomerDetailsById(@PathVariable String customerId) {
		return ResponseEntity.ok(customerService.getCustomerDetailsById(customerId));
	}

	@PostMapping("/customer")
	public ResponseEntity<ResponseDto> saveCustomerDetails(@RequestBody CustomerDto dto) {
		return ResponseEntity.ok(customerService.saveCustomerDetails(dto));
	}

	@GetMapping("/customers")
	public ResponseEntity<List<CustomerDto>> getAllCustomerDetails() {
		return ResponseEntity.ok(customerService.getAllCustomerDetails());
	}

	@DeleteMapping("/customer/{customerId}")
	public ResponseEntity<ResponseDto> deleteCustomerById(@PathVariable String customerId) {
		return ResponseEntity.ok(customerService.deleteCustomerById(customerId));
	}
}
