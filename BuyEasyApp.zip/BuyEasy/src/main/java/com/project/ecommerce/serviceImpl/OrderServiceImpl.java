package com.project.ecommerce.serviceImpl;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.project.ecommerce.dao.CustomerRepository;
import com.project.ecommerce.dao.OrderRepository;
import com.project.ecommerce.dao.ProductRepository;
import com.project.ecommerce.dao.ViewOrderRepository;
import com.project.ecommerce.dto.OrderDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.dto.ViewOrderDto;
import com.project.ecommerce.entity.CustomerEntity;
import com.project.ecommerce.entity.OrderEntity;
import com.project.ecommerce.entity.ProductEntity;
import com.project.ecommerce.entity.ViewOrderEntity;
import com.project.ecommerce.service.OrderService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {
	
	
	private final OrderRepository orderRepository;

	
	private final CustomerRepository customerRepository;


	private final ProductRepository productRepository;


	private final ViewOrderRepository viewOrderRepository;


	@Override
	public ResponseDto saveOrder(OrderDto dto) {
	    ResponseDto response = new ResponseDto();
	    try {
	      
	        Optional<CustomerEntity> customerOpt = customerRepository.findById(dto.getCustomerId());
	        if (!customerOpt.isPresent()) {
	            response.setMessage("Invalid Customer ID");
	            response.setStatusCode("400");
	            return response;
	        }

	      
	        if (dto.getProducts() == null || dto.getProducts().isEmpty()) {
	            response.setMessage("No products in the order");
	            response.setStatusCode("400");
	            return response;
	        }

	        
	        OrderEntity order = new OrderEntity();
	        order.setCustomerId(dto.getCustomerId());
	      
	        order.setOrderStatus(dto.getOrderStatus());
	        order.setOrderDate(dto.getOrderDate());
	        order.setTotalAmount(0); 
	     
	        order = orderRepository.save(order); 

	        int totalAmount = 0;


	        for (ViewOrderDto itemDto : dto.getProducts()) {
	            Optional<ProductEntity> productOpt = productRepository.findById(itemDto.getProductId());
	            if (!productOpt.isPresent()) continue;

	            ProductEntity product = productOpt.get();

	           
	     
	            int total = itemDto.getQuantity() * product.getPrice();

	         
	            ViewOrderEntity item = new ViewOrderEntity();
	            item.setOrder(order);
	            item.setCustomer(customerOpt.get());
	            item.setProduct(product);
	            item.setProductName(product.getProductName());
	            item.setQuantity(itemDto.getQuantity());
	            item.setMrp(product.getMrp()); 
	            item.setPrice(product.getPrice()); 
	            item.setTax(product.getTax()); 
	            item.setTotalAmount(total);

	          
	            order.getItems().add(item);
	            viewOrderRepository.save(item);
	
	            totalAmount += total;
	        }

	        
	        order.setTotalAmount(totalAmount);
	        orderRepository.save(order);

	        response.setMessage("Order Placed Successfully");
	        response.setStatusCode("200");
	    } catch (Exception e) {
	        response.setMessage("Error Occurred");
	        response.setStatusCode("500");
	    }

	    return response;
	}


	@Override
	public OrderDto getOrderById(String orderId) {
	    Optional<OrderEntity> orderOpt = orderRepository.findById(orderId);
	    if (!orderOpt.isPresent()) return null;

	    OrderEntity order = orderOpt.get();
	    OrderDto dto = new OrderDto();
	    dto.setOrderId(order.getOrderId());
	    dto.setCustomerId(order.getCustomerId());
	    dto.setOrderDate(order.getOrderDate());
	    dto.setOrderStatus(order.getOrderStatus());
	    dto.setTotalAmount(order.getTotalAmount());

	    return dto;
	}

	@Override
	public List<OrderDto> getAllOrders() {
	    List<OrderEntity> orders = orderRepository.findAll();
	    List<OrderDto> dtos = new ArrayList<>();

	    for (OrderEntity order : orders) {
	        OrderDto dto = new OrderDto();
	        dto.setOrderId(order.getOrderId());
	        dto.setCustomerId(order.getCustomerId());
	        dto.setOrderDate(order.getOrderDate());
	        dto.setOrderStatus(order.getOrderStatus());
	        dto.setTotalAmount(order.getTotalAmount());
	        dtos.add(dto);
	    }

	    return dtos;
	}

	@Override
	public ResponseDto deleteOrderById(String orderId) {
	    ResponseDto response = new ResponseDto();
	    try {
	        if (orderRepository.existsById(orderId)) {
	        	orderRepository.deleteById(orderId);
	        	viewOrderRepository.deleteByOrderOrderId(orderId);
		        response.setMessage("Order Deleted Successfully");
		        response.setStatusCode("200");
	        }
	        else
	        {
	        	response.setMessage("Order ID Not Found");
	            response.setStatusCode("404");
	            return response;
	        	
	        }
	    } catch (Exception e) {
	    	 response.setMessage("Deletion Failed");
		     response.setStatusCode("500");
	    	throw e;
	       
	    }

	    return response;
	}

	@Override
	public List<ViewOrderDto> getOrderItems(String orderId) {
	    List<ViewOrderEntity> items = viewOrderRepository.findByOrderOrderId(orderId);
	    List<ViewOrderDto> dtos = new ArrayList<>();

	    for (ViewOrderEntity item : items) {
	        ViewOrderDto dto = new ViewOrderDto();
	        dto.setItemId(item.getItemId());
	        dto.setOrderId(item.getOrder().getOrderId());
	        dto.setCustomerId(item.getCustomer().getCustomerId());
	        dto.setProductId(item.getProduct().getProductId());
	        dto.setProductName(item.getProduct().getProductName());
	        dto.setQuantity(item.getQuantity());
	        dto.setMrp(item.getMrp());
	        dto.setPrice(item.getPrice());
	        dto.setTax(item.getTax());
	        dto.setTotalAmount(item.getTotalAmount());
	        dtos.add(dto);
	    }

	    return dtos;
	}

   
	
}