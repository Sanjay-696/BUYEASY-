package com.project.ecommerce.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;


import com.project.ecommerce.dao.ViewOrderRepository;
import com.project.ecommerce.dto.CustomerDto;
import com.project.ecommerce.dto.OrderDto;
import com.project.ecommerce.dto.OrderResponseDto;
import com.project.ecommerce.dto.ProductDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.dto.ViewOrderDto;
import com.project.ecommerce.entity.CustomerEntity;
import com.project.ecommerce.entity.OrderEntity;
import com.project.ecommerce.entity.ProductEntity;
import com.project.ecommerce.entity.ViewOrderEntity;
import com.project.ecommerce.service.ViewOrderService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ViewOrderServiceImpl implements ViewOrderService {

    private final ViewOrderRepository viewOrderRepository;
   
    @Override
    public List<ViewOrderDto> getItemsByOrderId(String orderId) {
        List<ViewOrderEntity> entities = viewOrderRepository.findByOrderOrderId(orderId);
        return convertToDtoList(entities);
    }

    @Override
    public OrderResponseDto getOrderDetailsByCustomerId(String customerId) {
        List<ViewOrderEntity> viewOrderEntities = viewOrderRepository.findByCustomerCustomerId(customerId);

        if (viewOrderEntities.isEmpty()) {
            throw new RuntimeException("No orders found for customer ID: " + customerId);
        }

        ViewOrderEntity firstEntry = viewOrderEntities.get(0);

        CustomerEntity customerEntity = firstEntry.getCustomer();
        CustomerDto customerDto = new CustomerDto();
        customerDto.setCustomerId(customerEntity.getCustomerId());
        customerDto.setCustomerName(customerEntity.getCustomerName());
        customerDto.setMobileNumber(customerEntity.getMobileNumber());
        customerDto.setEmail(customerEntity.getEmail());
        customerDto.setAddress(customerEntity.getAddress());
        customerDto.setCreatedAt(customerEntity.getCreatedAt());
        
        OrderEntity orderEntity = firstEntry.getOrder();
        OrderDto orderDto = new OrderDto();
        orderDto.setOrderId(orderEntity.getOrderId());
        orderDto.setTotalAmount(orderEntity.getTotalAmount());
        orderDto.setOrderStatus(orderEntity.getOrderStatus());
        orderDto.setOrderDate(orderEntity.getOrderDate());

        List<ProductDto> productDtos = new ArrayList<>();
        for (ViewOrderEntity voe : viewOrderEntities) {
            ProductEntity productEntity = voe.getProduct();
            ProductDto productDto = new ProductDto();
            productDto.setProductId(productEntity.getProductId());
            productDto.setProductName(productEntity.getProductName());
            productDto.setMrp(productEntity.getMrp());
            productDto.setPrice(productEntity.getPrice());
            productDto.setTax(productEntity.getTax());
            productDto.setCreatedAt(productEntity.getCreatedAt());
        
            productDtos.add(productDto);
        }

        OrderResponseDto responseDto = new OrderResponseDto();
        responseDto.setCustomer(customerDto);
        responseDto.setOrder(orderDto);
        responseDto.setProducts(productDtos);
        return responseDto;
        
    }

    @Override
    public List<ViewOrderDto> getAllItems() {
        List<ViewOrderEntity> entities = viewOrderRepository.findAll();
        return convertToDtoList(entities);
    }

    @Override
    public ResponseDto deleteItemsByOrderId(String orderId) {
        ResponseDto response = new ResponseDto();

        try {
            boolean exists = viewOrderRepository.findByOrderOrderId(orderId).size() > 0;
            if (exists) {
                viewOrderRepository.deleteByOrderOrderId(orderId);
                response.setMessage("Order Items Deleted Successfully");
                response.setStatusCode("200");
            } else {
                response.setMessage("ORDER ID NOT FOUND");
                response.setStatusCode("404");
            }
        } catch (Exception e) {
            response.setMessage("Failed to Delete Items");
            response.setStatusCode("500");
            throw e;
        }
        return response;
    }

    private List<ViewOrderDto> convertToDtoList(List<ViewOrderEntity> entities) {
        List<ViewOrderDto> dtoList = new ArrayList<>();
        for (ViewOrderEntity entity : entities) {
            ViewOrderDto dto = new ViewOrderDto();
            dto.setItemId(entity.getItemId());
            dto.setOrderId(entity.getOrder().getOrderId());
            dto.setCustomerId(entity.getCustomer().getCustomerId());
            dto.setProductId(entity.getProduct().getProductId());
            dto.setProductName(entity.getProduct().getProductName());
            dto.setQuantity(entity.getQuantity());
            dto.setMrp(entity.getMrp());
            dto.setPrice(entity.getPrice());
            dto.setTax(entity.getTax());
            dto.setTotalAmount(entity.getTotalAmount());
            dtoList.add(dto);
        }
        return dtoList;
    }
}
