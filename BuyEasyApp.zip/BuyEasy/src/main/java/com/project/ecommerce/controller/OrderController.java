package com.project.ecommerce.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.ecommerce.dto.OrderDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.dto.ViewOrderDto;
import com.project.ecommerce.service.OrderService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("api")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    
    @PostMapping("/order")
    public ResponseEntity<ResponseDto> saveOrder(@RequestBody OrderDto dto) {
        return ResponseEntity.ok(orderService.saveOrder(dto));
    }

    
    @GetMapping("/order/{orderId}")
    public ResponseEntity<OrderDto> getOrderById(@PathVariable String orderId) {
        return ResponseEntity.ok(orderService.getOrderById(orderId));
    }

   
    @GetMapping("/order")
    public ResponseEntity<List<OrderDto>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    
    @DeleteMapping("/delete/{orderId}")
    public ResponseEntity<ResponseDto> deleteOrderById(@PathVariable String orderId) {
        return ResponseEntity.ok(orderService.deleteOrderById(orderId));
    }

   
    @GetMapping("/order/{orderId}/items")
    public List<ViewOrderDto> getOrderItems(@PathVariable String orderId) {
        return orderService.getOrderItems(orderId);
    }
}

 


