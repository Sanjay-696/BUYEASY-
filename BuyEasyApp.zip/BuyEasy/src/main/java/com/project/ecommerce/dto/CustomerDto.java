package com.project.ecommerce.dto;

import java.time.LocalDateTime;



import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDto {

    private String customerId;         

    private String customerName;        

    private String mobileNumber;       

    private String email;              

    private String address;
    
    private LocalDateTime createdAt;
}