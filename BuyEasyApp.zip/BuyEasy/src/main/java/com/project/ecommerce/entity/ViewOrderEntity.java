package com.project.ecommerce.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "order_items")
@Data
public class ViewOrderEntity {

    @Id
    @UuidGenerator
    @Column(name = "item_id")
    private String itemId;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private OrderEntity order;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private CustomerEntity customer;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private ProductEntity product;

    @Column(name="product_name")
    private String ProductName;
    
    private int quantity;

    private int mrp;

    private int price;

    private int tax;

    @Column(name = "total_amount")
    private int totalAmount;
}


