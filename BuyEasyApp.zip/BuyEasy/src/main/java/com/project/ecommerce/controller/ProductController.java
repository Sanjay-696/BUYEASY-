package com.project.ecommerce.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


import com.project.ecommerce.dto.ProductDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.service.ProductService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("api")
@RequiredArgsConstructor
public class ProductController {

	private final ProductService productService;
	
	@GetMapping("/product/{productId}")
	public ResponseEntity<ProductDto> getProductDetailsById(@PathVariable("customerId") String productId) {
		return ResponseEntity.ok(productService.getProductDetailsById(productId));
	}

	@PostMapping("/product")
	public ResponseEntity<ResponseDto> saveProductDetails(@RequestBody ProductDto dto) {
		return ResponseEntity.ok(productService.saveProductDetails(dto));
	}

	@GetMapping("/products")
	public ResponseEntity<List<ProductDto>> getAllProductDetails() {
		return ResponseEntity.ok(productService.getAllProductDetails());
	}

	@DeleteMapping("/product/{productId}")
	public ResponseEntity<ResponseDto> deleteProductById(@PathVariable String productId) {
		return ResponseEntity.ok(productService.deleteProductById(productId));
	}
}
