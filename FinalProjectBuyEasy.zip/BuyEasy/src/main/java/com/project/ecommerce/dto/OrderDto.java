package com.project.ecommerce.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class OrderDto {
	
    private String orderId;
    
    private String customerId;
    
    private String email;
    
    private List<ViewOrderDto> products;
    
    private int totalAmount;
    
    private String orderStatus;
    
    private LocalDateTime orderDate;
}
