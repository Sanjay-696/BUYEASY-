package com.project.ecommerce.service;

import java.util.List;

import com.project.ecommerce.dto.CustomerDto;
import com.project.ecommerce.dto.ResponseDto;

public interface CustomerService {
	
	CustomerDto getCustomerDetailsById(String customerId);

	ResponseDto saveCustomerDetails(CustomerDto dto);

	List<CustomerDto> getAllCustomerDetails();

	ResponseDto deleteCustomerById(String customerId);
	
	
}
