package com.project.ecommerce.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto {

	private String productId;
	
	private String productName;
	
	private Integer mrp;
	
	private Integer price;
	
	private Integer tax;
	
	private LocalDateTime createdAt;
}
