package com.project.ecommerce.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ViewController {
	
	@GetMapping("/create-customer")
	public ModelAndView createCustomerPage()
	{
		return new ModelAndView("create-customer");
	}
	
	@GetMapping("/create-products")
	public ModelAndView createProductsPage()
	{
		return new ModelAndView("products");
	}

	@GetMapping("/get-customers")
	public ModelAndView showCustomerListPage() {
	    return new ModelAndView("customer-list");  
	}
	
	@GetMapping("/orders")
	public ModelAndView showOrderListPage() {
	    return new ModelAndView("order");  
	}
	
	@GetMapping("/home")
	public ModelAndView showHomePage() {
	    return new ModelAndView("home");  
	}
	
}
