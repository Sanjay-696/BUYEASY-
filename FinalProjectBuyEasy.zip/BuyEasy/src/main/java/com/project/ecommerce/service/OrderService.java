package com.project.ecommerce.service;

import java.util.List;

import com.project.ecommerce.dto.OrderDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.dto.ViewOrderDto;

public interface OrderService {

    
    ResponseDto saveOrder(OrderDto dto);

    
    OrderDto getOrderById(String orderId);

   
    List<OrderDto> getAllOrders();

    
    ResponseDto deleteOrderById(String orderId);

    
    List<ViewOrderDto> getOrderItems(String orderId);

 
    ResponseDto addProductToOrder(ViewOrderDto dto);

  
   
}
