package com.project.ecommerce.service;

import java.util.List;

import com.project.ecommerce.dto.OrderResponseDto;
import com.project.ecommerce.dto.ResponseDto;
import com.project.ecommerce.dto.ViewOrderDto;

public interface ViewOrderService {

    List<ViewOrderDto> getItemsByOrderId(String orderId);

    OrderResponseDto getOrderDetailsByCustomerId(String customerId);

    List<ViewOrderDto> getAllItems();

    ResponseDto deleteItemsByOrderId(String orderId);
}
