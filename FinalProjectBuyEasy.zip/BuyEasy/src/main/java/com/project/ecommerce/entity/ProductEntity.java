package com.project.ecommerce.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="products")
@Data
public class ProductEntity {
	
	@Id
	@UuidGenerator
	@Column(name="product_id")
	private String productId;
	
	@Column(name="product_name",unique=true)
	private String productName;
	
	private Integer mrp;
	
	private Integer price;
	
	private Integer tax;
	
	@CreationTimestamp
	@Column(name="created_at")
	private LocalDateTime createdAt;

}
