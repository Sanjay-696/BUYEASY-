package com.project.ecommerce.entity;

import jakarta.persistence.*;



import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import lombok.Data;


@Entity
@Table(name = "orders")
@Data
public class OrderEntity {

    @Id
    @UuidGenerator
    @Column(name = "order_id")
    private String orderId;

    @Column(name = "customer_id")
    private String customerId;
   

    @Column(name="total_amount")
    private int totalAmount;

    @Column(name="order_status")
    private String orderStatus;

    @CreationTimestamp
    @Column(name="order_date")
    private LocalDateTime orderDate;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<ViewOrderEntity> items = new ArrayList<>();
}
